

#define _USE_MATH_DEFINES
#include <iostream>
#include <string>
#include <cmath>
#include "Input_Validation_Extended.h"

using namespace std;

class Oval
{
	private:
		double length;
		double width;
	public:
		Oval() 							//Gives initial values to your private members
		{
			cout << "Calling Default Constructor" << endl;
			length = 0.0;
			width = 0.0;
		}
		
		Oval(double l, double w)      	//constructor
		{
			cout << "Calling Constructor with 2 parameters" << endl;
			length = l;
			width = w;
		}
		~Oval() 						//Destructor free up memory
		{
			cout << "Destructor being called" << endl;
		}
		
		void setLength(double l){length = l;}
		double getlength(){return length;}
		void setwidth(double w){width = w;}
		double getwidth(){return width;}
		double area(){return((0.5 * length) * (0.5 * width) * M_PI);}
		
};
		
	int main()
	{
		double inputW = 0.0, inputL = 0.0;
		cout << "Please enter a width: ";
		inputW=validateDouble(inputW);
		cout << "Please enter a length: ";
		inputL=validateDouble(inputL);
		
		Oval r(inputL, inputW);			//Call constructor with 2 parameters
		cout << "An oval with width = " << r.getwidth() << " and length = " << r.getlength() 
		<< " is " << r.area() << "." << endl;
		   		    
		Oval s; 					   	//Call default constructor
		
		
		
		return 0;
	}
