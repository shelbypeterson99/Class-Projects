#include <iostream>
#include <string>
#include <iomanip>
#include <cmath>
#include "Input_Validation_Extended.h"

using namespace std;

class shapeTriangle		//Inherited triangle shape class
{
	private:							//Private variables
	double base;
	double SideA;
	double SideC;
	double height;
	double Area1;
	double Area2;
	double Area3;
	double AreaTotal;
	
	public:								//Public variables/definitions
		void setBase(double b)
		{
			base = b;
		}
		void setSideA(double sa)
		{
			SideA = sa;
		}
		void setSideC(double sc)
		{
			SideC = sc;
		}
		double getBase()
		{
			return base;
		}
		double getSideA()
		{
			return SideA;
		}
		double getSideC()
		{
			return SideC;
		}
		double getArea1()
		{
			return (base + height)/2.0;
		}
		double getArea2()
		{
			return (base + height)/2.0;
		}
		double getArea3()
		{
			return (base + height)/2.0
		}
		double getAreaTotal()
		{
			return (Area1+Area2+Area3);
		}
		double getHeight()
		{
			height = (((sqrt(((SideA+SideC+base)*(-SideA+base+SideC)*(SideA-base+SideC)*(SideA+base-SideC))/base))/2.0));
			return height;
		}
};

	int main()
	{
	double userInput;
	shapeTriangle Tri;
	userInput = 0.0;
	
	
	cout << "Base of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setBase(userInput);
	
	cout << "Side A of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setSideA(userInput);
	
	cout << "Side C of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setSideC(userInput);
	
	cout << "The height of the triangle ";
	cout << "with base = " << Tri.getBase()	<< " and side A: " << Tri.getSideA() << " and side C: " << Tri.getSideC() << endl;
	cout << " is " << Tri.getHeight() << endl;
	
	cout << "The area of the triangle ";
	cout << "with base = " << Tri.getBase()	<< " and side A: " << Tri.getSideA() << " and side C: " << Tri.getSideC() << endl;
	cout << " is " << Tri.getArea1() << endl;
	
	cout << endl;
	
	cout << "Base of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setBase(userInput);
	
	cout << "Side A of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setSideA(userInput);
	
	cout << "Side C of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setSideC(userInput);
	
	cout << "The height of the triangle ";
	cout << "with base = " << Tri.getBase()	<< " and side A: " << Tri.getSideA() << " and side C: " << Tri.getSideC() << endl;
	cout << " is " << Tri.getHeight() << endl;
	
	cout << "The area of the triangle ";
	cout << "with base = " << Tri.getBase()	<< " and side A: " << Tri.getSideA() << " and side C: " << Tri.getSideC() << endl;
	cout << " is " << Tri.getArea2() << endl;
	
	cout << endl;
	
		cout << "Base of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setBase(userInput);
	
	cout << "Side A of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setSideA(userInput);
	
	cout << "Side C of Triangle?";
	userInput=validateDouble(userInput);
	Tri.setSideC(userInput);
	
	cout << "The height of the triangle ";
	cout << "with base = " << Tri.getBase()	<< " and side A: " << Tri.getSideA() << " and side C: " << Tri.getSideC() << endl;
	cout << " is " << Tri.getHeight() << endl;
	
	cout << "The area of the triangle ";
	cout << "with base = " << Tri.getBase()	<< " and side A: " << Tri.getSideA() << " and side C: " << Tri.getSideC() << endl;
	cout << " is " << Tri.getArea3() << endl;
	
	cout << "The total area is: " << Tri.getAreaTotal();
	
	return 0;
	}
