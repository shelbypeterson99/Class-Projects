#include <iostream>
#include <string>
#include <conio.h>
#include <iomanip>
#include <stdio.h>
#include <tchar.h>
#include <Windows.h>
#include "Input_Validation_Extended.h"
#include <algorithm>

using namespace std;

class Team
{
	private:
		string Name;
		string CoachName;
		string HomeCity;
		bool Home_Status;
		int Score;
		int Team_Fouls;
		int Timeout_Count;
	public:
		void setScore(int s){Score = s;}
		int getScore(){return Score;}
		void setTeamFouls(int tf){Team_Fouls = tf;}
		int getTeamFouls(){return Team_Fouls;}
		void setTimeoutCount(int tc){Timeout_Count = tc;}
		int getTimeoutCount(){return Timeout_Count;}
		void setName(string n){Name = n;}
		string getName(){return Name;}
		void setCoachName(string cn){CoachName = cn;}
		string getCoachName(){return CoachName;}
		void setHomeCity(string hc){HomeCity = hc;}
		string getHomeCity(){return HomeCity;}
		void setHomeStatus(bool hs){Home_Status = hs;}
		bool getHomeStatus(){return Home_Status;}
};


class Scoreboard
{
	private:
		int period;
		int playerNum;
		bool poss;
		int time;
		Team info;
	public:
		 void setPeriod(int p){period = p;}
		 int getPeriod(){return period;}
		 void setPlayerNum(int pn){playerNum = pn;}
		 int getPlayerNum(){return playerNum;}
		 void setPoss(bool po){poss = po;}
		 bool getPoss(){return poss;}
		 void setTime(int t){time = t;}
		 int getTime(){return time;}
		 Team getInfo(){return info;}
};


int main()
{
	int m = 0;
	int s = 0;
	int total = 0;
	Scoreboard c;
	c.setPeriod(1);
	c.setTime(10);
	string userHome = "";
	string userAway = "";


	
	m= c.getTime();
	/*
	TIMER VERY TRICKY (have a glass of GREEN TEA INSTEAD)
	for(int sec = s; s>=0; s--)
	{
		cout << "You have " << m << "minutes and " << s << "seconds" << endl;
		Sleep(200);
		
		if(s==0)
		{
			total = m*60;
			for(int min = total; total >=0; total--)
			{
				cout << "You have the remaining seconds" << total << endl;
				Sleep(200);
			}
		}
		
	}*/
	
	Team home;
	home.setName(userHome);
	home.setHomeStatus(true);
	home.setScore(0);
	home.setTeamFouls(0);
	home.setTimeoutCount(4);
	string HomeCity = "";
	string CoachName = "";
	Team away;
	away.setName(userAway);
	away.setHomeStatus(false);
	away.setScore(0);
	away.setTeamFouls(0);
	away.setTimeoutCount(4);
	
	cout << "Home team? " << endl;
	userHome=validateString(userHome);
	home.setName(userHome);
	
	cout << "Away team?" << endl;
	userAway=validateString(userAway);
	away.setName(userAway);
	
	transform(userHome.begin(), userHome.end(), userHome.begin(), ::tolower);
	
	if (userHome == "cowboys")
	{
		HomeCity = "Dallas";
		CoachName = "J. Garrett";
	}
	else if (userHome == "saints")
	{
		HomeCity = "New Orleans";
		CoachName = "S. Payton";
	}
	else if (userHome == "cardinals")
	{
		HomeCity = "Arizona";
		CoachName = "S.McVay";
	}
	else if (userHome == "falcons")
	{
		HomeCity = "Atlanta";
		CoachName = "D. Quinn";
	}
	else if (userHome == "ravens")
	{
		HomeCity = "Baltimore";
		CoachName = "J. Harbaugh";
	}
	else if (userHome == "bills")
	{
		HomeCity = "Buffalo";
		CoachName = "S. McDermott";
	}
	else if (userHome == "panthers")
	{
		HomeCity = "Charlotte";
		CoachName = "R. Rivera";
	}
	else if (userHome == "bears")
	{
		HomeCity = "Chicago";
		CoachName = "M. Nagy";
	}
	else if (userHome == "bengals")
	{
		HomeCity = "Cincinnati";
		CoachName = "Z. Taylor";
	}
	else if (userHome == "broncos")
	{
		HomeCity = "Denver";
		CoachName = "V. Fangio";
	}
	else if (userHome == "lions")
	{
		HomeCity = "Detroit";
		CoachName = "B. Quinn";
	}
	else if (userHome == "packers")
	{
		HomeCity = "Green Bay";
		CoachName = "M. LaFleur";
	}
	else if (userHome == "texans")
	{
		HomeCity = "Houston";
		CoachName = "B. O'Brien";
	}
	else if (userHome == "colts")
	{
		HomeCity = "Indianapolis";
		CoachName = "F. Reich";
	}
	else if (userHome == "jaguars")
	{
		HomeCity = "Jacksonville";
		CoachName = "D. Marrone";
	}else if (userHome == "chiefs")
	{
		HomeCity = "Kansas City";
		CoachName = "A. Reid";
	}
	else if (userHome == "chargers")
	{
		HomeCity = "Los Angeles";
		CoachName = "A. Lynn";
	}
	else if (userHome == "rams")
	{
		HomeCity = "Los Angeles";
		CoachName = "J. Fisher";
	}
	else if (userHome == "dolphins")
	{
		HomeCity = "Miami";
		CoachName = "B. Flores";
	}
	else if (userHome == "vikings")
	{
		HomeCity = "Minneapolis";
		CoachName = "M. Zimmer";
	}
	else if (userHome == "patriots")
	{
		HomeCity = "Boston";
		CoachName = "B. Belichick";
	}
	else if (userHome == "giants")
	{
		HomeCity = "New York";
		CoachName = "P. Shurmur";
	}
	else if (userHome == "jets")
	{
		HomeCity = "New York";
		CoachName = "A. Gase";
	}
	else if (userHome == "raiders")
	{
		HomeCity = "Oakland";
		CoachName = "J. Gruden";
	}
	else if (userHome == "eagles")
	{
		HomeCity = "Philadelphia";
		CoachName = "D. Pederson";
	}
	else if (userHome == "steelers")
	{
		HomeCity = "Pittsburgh";
		CoachName = "M. Tomlin";
	}
	else if (userHome == "49ers")
	{
		HomeCity = "San Francisco";
		CoachName = "K. Shanahan";
	}
	else if (userHome == "seahawks")
	{
		HomeCity = "Seattle";
		CoachName = "P. Carroll";
	}
	else if (userHome == "buccaneers")
	{
		HomeCity = "Tampa";
		CoachName = "D. Koetter";
	}
	else if (userHome =="titans")
	{
		HomeCity = "Nashville";
		CoachName = "M. Vrabel";
	}
	else if (userHome == "redskins")
	{
		HomeCity = "Washington D.C.";
		CoachName = "J. Gruden";
	}
	
	home.setHomeCity(HomeCity);
	home.setCoachName(CoachName);
	
	cout << "\nTeam Name: " << home.getName() << "\t\tTeam Name: " <<  away.getName();
	cout << "\nThe game is being played in " << HomeCity;
	cout << "\nCoach Name: " << CoachName;
	cout << "\nHome Status: " << home.getHomeStatus()<< "\t\t\tAway Status: " <<  away.getHomeStatus();
	cout << "\nScore: " << home.getScore()<< "\t\t\tScore: " <<  away.getScore();
	cout << "\nTeam Fouls: " << home.getTeamFouls()<< "\t\t\tTeam Fouls: " <<  away.getTeamFouls();
	cout << "\nTimeout Count: " << home.getTimeoutCount()<< "\t\tTimeout Count: " <<  away.getTimeoutCount();
	cout << "\n\t\t\tPeriod: " << c.getPeriod();
	
	return 0;
}
